"""Core review rules."""
